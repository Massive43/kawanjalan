package com.marijalanjalan.go

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

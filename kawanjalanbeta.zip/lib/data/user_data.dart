// lib/data/user_data.dart
class UserDatabase {
  // Map ini bertindak sebagai penyimpanan data sementara (RAM)
  static Map<String, String> data = {
    "username": "user",
    "email": "user@gmail.com",
    "phone": "+62 812-3456-7890",
  };

  // Fungsi ini dipanggil di RegisterScreen untuk memperbarui data
  static void saveUser(String name, String mail, String telp) {
    data["username"] = name;
    data["email"] = mail;
    data["phone"] = telp;
  }
}

import 'package:flutter/material.dart';
import 'home_screen.dart';
import 'forgot_password_screen.dart';
import 'register_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isPasswordObscured = true;

  // Mendefinisikan controller untuk mengambil input dari user
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // Fungsi untuk memvalidasi input saat tombol login ditekan
  void _validateAndLogin() {
    String username = _usernameController.text.trim();
    String password = _passwordController.text.trim();

    // Peringatan jika username dan password kosong
    if (username.isEmpty || password.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Username/Email dan Password tidak boleh kosong!"),
          backgroundColor: Colors.redAccent,
          duration: Duration(seconds: 2),
        ),
      );
      return;
    }

    // Jika validasi sukses, lanjut navigasi ke HomeScreen
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const HomeScreen()),
    );
  }

  @override
  void dispose() {
    // Membersihkan controller ketika screen tidak digunakan lagi
    _usernameController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 280,
              width: double.infinity,
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: NetworkImage(
                      'https://images.unsplash.com/photo-1501503069356-3c6b82a17d89?q=80&w=1000'),
                  fit: BoxFit.cover,
                ),
              ),
              child: Stack(
                children: [
                  Positioned(top: 40, left: 20, child: _logo()),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(25),
              child: Column(
                children: [
                  _socialBtn("Continue with google", Colors.white, Colors.black,
                      Icons.g_mobiledata),
                  const SizedBox(height: 12),
                  _socialBtn("Continue with Facebook", const Color(0xFF1877F2),
                      Colors.white, Icons.facebook),
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 20),
                    child: Row(children: const [
                      Expanded(child: Divider(color: Colors.white24)),
                      Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Text("or",
                              style: TextStyle(color: Colors.white))),
                      Expanded(child: Divider(color: Colors.white24)),
                    ]),
                  ),
                  _inputField("Username/ Email", false,
                      _usernameController), // Ditambahkan controller
                  const SizedBox(height: 15),
                  GestureDetector(
                    onTap: () {
                      setState(() {
                        _isPasswordObscured = !_isPasswordObscured;
                      });
                    },
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Icon(
                            _isPasswordObscured
                                ? Icons.visibility_off
                                : Icons.visibility,
                            size: 16,
                            color: Colors.grey),
                        const SizedBox(width: 5),
                        Text(
                            _isPasswordObscured
                                ? "Show Password"
                                : "Hide Password",
                            style: const TextStyle(
                                color: Colors.grey, fontSize: 12)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 5),
                  _inputField("Password", _isPasswordObscured,
                      _passwordController), // Ditambahkan controller
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const RegisterScreen()),
                            );
                          },
                          child: const Text("Create new account",
                              style:
                                  TextStyle(color: Colors.blue, fontSize: 12))),
                      TextButton(
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const ForgotPasswordScreen()),
                            );
                          },
                          child: const Text("Forgot Password ?",
                              style:
                                  TextStyle(color: Colors.blue, fontSize: 12))),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed:
                        _validateAndLogin, // Memanggil fungsi pengecekan validasi kosong
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      side: const BorderSide(color: Colors.white54),
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30)),
                    ),
                    child: const Text("Login",
                        style: TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.white)),
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "By creating account, Your aggre to our Terms and have read and acknowledge the Global Privacy Statement.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.grey, fontSize: 10),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _logo() =>
      Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text("KAWAN",
            style: TextStyle(
                color: Color(0xFF9ACD32),
                fontSize: 24,
                fontWeight: FontWeight.bold)),
        Text("JALAN",
            style: TextStyle(
                color: Colors.orange,
                fontSize: 24,
                fontWeight: FontWeight.bold)),
      ]);

  Widget _socialBtn(String text, Color bg, Color txt, IconData icon) =>
      Container(
        height: 50,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(30),
            color: Colors.transparent,
            border: Border.all(color: Colors.white54)),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: Colors.white),
            const SizedBox(width: 10),
            Text(text,
                style: const TextStyle(
                    color: Colors.white, fontWeight: FontWeight.w400)),
          ],
        ),
      );

  // Menambahkan parameter controller agar dapat dihubungkan ke widget TextField
  Widget _inputField(
          String hint, bool obscure, TextEditingController controller) =>
      TextField(
        controller: controller,
        obscureText: obscure,
        style: const TextStyle(color: Colors.white),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.grey),
          filled: true,
          fillColor: Colors.white10,
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Colors.white24)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
              borderSide: const BorderSide(color: Colors.blue)),
        ),
      );
}

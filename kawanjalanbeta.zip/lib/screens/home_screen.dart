import 'package:flutter/material.dart';
import 'jadwal_screen.dart';
import 'profile_screen.dart';
import 'payment_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;
  final List<Map<String, String>> _favoriteList = [];

  // Struktur data untuk menyimpan review berdasarkan nama destinasi
  final Map<String, List<Map<String, dynamic>>> _destinationReviews = {
    'Kawah Putih Ciwidey': [
      {
        'user': 'Budi',
        'rating': 5,
        'comment': 'Tempatnya bagus banget dan sejuk!'
      }
    ],
    'Curug Cikuluwung': [
      {
        'user': 'Siti',
        'rating': 4,
        'comment': 'Airnya jernih, jalurnya lumayan menantang.'
      }
    ]
  };

  void _toggleFavorite(String name, String loc, String img) {
    setState(() {
      int index = _favoriteList.indexWhere((item) => item['name'] == name);
      if (index != -1) {
        _favoriteList.removeAt(index);
      } else {
        _favoriteList.add({'name': name, 'loc': loc, 'img': img});
      }
    });
  }

  // Fungsi untuk menambahkan review baru ke destinasi tertentu
  void _addReview(
      String destinationName, String user, int rating, String comment) {
    setState(() {
      if (!_destinationReviews.containsKey(destinationName)) {
        _destinationReviews[destinationName] = [];
      }
      _destinationReviews[destinationName]!.insert(0, {
        'user': user,
        'rating': rating,
        'comment': comment,
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = [
      HomeBody(
        favoriteList: _favoriteList,
        onFavoriteToggle: _toggleFavorite,
        reviewsData: _destinationReviews,
        onAddReview: _addReview,
      ),
      const JadwalScreen(),
      FavoritePage(
        favoriteList: _favoriteList,
        onDelete: (name) {
          setState(() {
            _favoriteList.removeWhere((item) => item['name'] == name);
          });
        },
      ),
      const ProfileScreen(),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        onTap: (index) => setState(() => _currentIndex = index),
        type: BottomNavigationBarType.fixed,
        backgroundColor: const Color(0xFF1D2733),
        selectedItemColor: Colors.blueAccent,
        unselectedItemColor: Colors.white54,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Beranda'),
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_month), label: 'Jadwal'),
          BottomNavigationBarItem(icon: Icon(Icons.favorite), label: 'Favorit'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profil'),
        ],
      ),
    );
  }
}

// --- BAGIAN BODY BERANDA ---
class HomeBody extends StatefulWidget {
  final List<Map<String, String>> favoriteList;
  final Function(String, String, String) onFavoriteToggle;
  final Map<String, List<Map<String, dynamic>>> reviewsData;
  final Function(String, String, int, String) onAddReview;

  const HomeBody({
    super.key,
    required this.favoriteList,
    required this.onFavoriteToggle,
    required this.reviewsData,
    required this.onAddReview,
  });

  @override
  State<HomeBody> createState() => _HomeBodyState();
}

class _HomeBodyState extends State<HomeBody> {
  final TextEditingController _searchController = TextEditingController();
  bool isSearching = false;
  List<Map<String, String>> searchResults = [];
  List<String> latestSearches = [];

  final List<Map<String, String>> allDestinations = [
    {
      'name': 'Kawah Putih Ciwidey',
      'loc': 'Kab.Bandung',
      'img':
          'https://img.inews.co.id/media/600/files/networks/2023/11/14/13051_kawah-putih.jpg'
    },
    {
      'name': 'Geopark Ciletuh',
      'loc': 'Sukabumi',
      'img':
          'https://image.idntimes.com/post/20190702/collage-078251dc297ff695f958b4e7d5e02cc4.jpg'
    },
    {
      'name': 'Taman Safari',
      'loc': 'Bogor',
      'img':
          'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2d/f0/b3/c4/cover-taman-safari-indonesia.jpg?w=900&h=-1&s=1'
    },
    {
      'name': 'Curug Cikuluwung',
      'loc': 'Bogor',
      'img':
          'https://images.unsplash.com/photo-1589118949245-7d38baf380d6?q=80&w=500'
    },
    {
      'name': 'Kebun Raya Bogor',
      'loc': 'Bogor',
      'img':
          'https://res.klook.com/image/upload/c_crop,h_427,w_1079,x_0,y_151/w_750,h_469,c_fill,q_85/w_80,x_15,y_15,g_south_west,l_Klook_water_br_trans_yhcmh3/activities/sm3rpprl3fnhdk6vcr7v.jpg'
    },
    {
      'name': 'Lembang Park',
      'loc': 'Bandung',
      'img':
          'https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=500'
    },
    {
      'name': 'Pantai Pangandaran',
      'loc': 'Jawa Barat',
      'img':
          'https://i0.wp.com/www.pakettourbelitung.net/wp-content/uploads/2019/02/pantai-pangandaran.jpg?fit=1350%2C800&ssl=1'
    },
  ];

  void _handleSearch(String query) {
    setState(() {
      if (query.isEmpty) {
        isSearching = false;
        searchResults = [];
      } else {
        isSearching = true;
        searchResults = allDestinations
            .where((dest) =>
                dest['name']!.toLowerCase().contains(query.toLowerCase()) ||
                dest['loc']!.toLowerCase().contains(query.toLowerCase()))
            .toList();
      }
    });
  }

  void _saveSearch(String query) {
    if (query.isNotEmpty && !latestSearches.contains(query)) {
      setState(() {
        latestSearches.insert(0, query);
        if (latestSearches.length > 5) latestSearches.removeLast();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 25),
            _buildSearchBar(),
            if (isSearching) ...[
              const SizedBox(height: 20),
              const Text("Hasil Pencarian",
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              const SizedBox(height: 15),
              searchResults.isEmpty
                  ? const Center(
                      child: Text("Destinasi tidak ditemukan",
                          style: TextStyle(color: Colors.white54)))
                  : ListView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      itemCount: searchResults.length,
                      itemBuilder: (context, index) {
                        final d = searchResults[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 15),
                          child: _recommendationCard(
                              context, d['name']!, d['loc']!, d['img']!),
                        );
                      },
                    ),
            ] else ...[
              if (latestSearches.isNotEmpty) ...[
                const SizedBox(height: 20),
                const Text("Pencarian Terakhir",
                    style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent)),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 10,
                  children: latestSearches
                      .map((s) => ActionChip(
                            label: Text(s,
                                style: const TextStyle(
                                    fontSize: 12, color: Colors.white)),
                            backgroundColor: Colors.white10,
                            onPressed: () {
                              _searchController.text = s;
                              _handleSearch(s);
                            },
                          ))
                      .toList(),
                ),
              ],
              const SizedBox(height: 30),
              const Text('Destinasi Terlaris',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              const SizedBox(height: 15),
              SizedBox(
                height:
                    240, // Ditambah sedikit tingginya agar muat tombol review
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  children: allDestinations.map((dest) {
                    return _itemCard(
                        context, dest['name']!, dest['loc']!, dest['img']!);
                  }).toList(),
                ),
              ),
              const SizedBox(height: 30),
              const Text('Rekomendasi Untuk Anda',
                  style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white)),
              const SizedBox(height: 15),
              _recommendationCard(context, 'Pantai Pangandaran', 'Jawa Barat',
                  'https://i0.wp.com/www.pakettourbelitung.net/wp-content/uploads/2019/02/pantai-pangandaran.jpg?fit=1350%2C800&ssl=1'),
              const SizedBox(height: 15),
              _recommendationCard(context, 'Kebun Raya Bogor', 'Bogor',
                  'https://res.klook.com/image/upload/c_crop,h_427,w_1079,x_0,y_151/w_750,h_469,c_fill,q_85/w_80,x_15,y_15,g_south_west,l_Klook_water_br_trans_yhcmh3/activities/sm3rpprl3fnhdk6vcr7v.jpg'),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Row(children: [
          Text("KAWAN ",
              style: TextStyle(
                  color: Colors.lightGreenAccent,
                  fontWeight: FontWeight.bold,
                  fontSize: 22)),
          Text("JALAN",
              style: TextStyle(
                  color: Colors.orange,
                  fontWeight: FontWeight.bold,
                  fontSize: 22)),
        ]),
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: Colors.white10, borderRadius: BorderRadius.circular(12)),
          child: const Icon(Icons.notifications_none, color: Colors.white),
        )
      ],
    );
  }

  Widget _buildSearchBar() {
    return TextField(
      controller: _searchController,
      onChanged: _handleSearch,
      onSubmitted: (val) {
        _handleSearch(val);
        _saveSearch(val);
      },
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: 'Cari destinasi...',
        hintStyle: const TextStyle(color: Colors.white38),
        prefixIcon: const Icon(Icons.search, color: Colors.white54),
        suffixIcon: isSearching
            ? IconButton(
                icon: const Icon(Icons.clear, color: Colors.white54),
                onPressed: () {
                  _searchController.clear();
                  _handleSearch("");
                })
            : null,
        filled: true,
        fillColor: Colors.white10,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(30),
            borderSide: BorderSide.none),
      ),
    );
  }

  Widget _itemCard(BuildContext context, String name, String loc, String img) {
    bool isFavorited = widget.favoriteList.any((item) => item['name'] == name);
    return Container(
      width: 160,
      margin: const EdgeInsets.only(right: 15),
      decoration: BoxDecoration(
          color: Colors.white10, borderRadius: BorderRadius.circular(15)),
      child: Stack(
        children: [
          GestureDetector(
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (context) => PaymentScreen())),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(15)),
                  child: Image.network(img,
                      height: 110, width: 160, fit: BoxFit.cover),
                ),
                Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(name,
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 14,
                              color: Colors.white),
                          overflow: TextOverflow.ellipsis),
                      Text(loc,
                          style: const TextStyle(
                              fontSize: 12, color: Colors.white54)),
                      const SizedBox(height: 8),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // MODIFIKASI: Tombol lihat review diletakkan di bagian bawah item card
          Positioned(
            bottom: 5,
            left: 10,
            child: TextButton(
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ReviewScreen(
                    destinationName: name,
                    reviews: widget.reviewsData[name] ?? [],
                    onAddReview: widget.onAddReview,
                  ),
                ),
              ),
              style: TextButton.styleFrom(
                  padding: EdgeInsets.zero, minimumSize: const Size(0, 25)),
              child: const Text("Lihat Review",
                  style: TextStyle(color: Colors.blueAccent, fontSize: 12)),
            ),
          ),
          Positioned(
            top: 5,
            right: 5,
            child: IconButton(
              onPressed: () => widget.onFavoriteToggle(name, loc, img),
              icon: Icon(isFavorited ? Icons.favorite : Icons.favorite_border,
                  color: isFavorited ? Colors.red : Colors.white, size: 20),
            ),
          ),
        ],
      ),
    );
  }

  Widget _recommendationCard(
      BuildContext context, String name, String loc, String img) {
    bool isFavorited = widget.favoriteList.any((item) => item['name'] == name);
    return Container(
      decoration: BoxDecoration(
          color: Colors.white10, borderRadius: BorderRadius.circular(15)),
      child: Column(
        children: [
          Stack(
            children: [
              ClipRRect(
                borderRadius:
                    const BorderRadius.vertical(top: Radius.circular(15)),
                child: Image.network(img,
                    height: 180, width: double.infinity, fit: BoxFit.cover),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: CircleAvatar(
                  backgroundColor: Colors.black45,
                  child: IconButton(
                    onPressed: () => widget.onFavoriteToggle(name, loc, img),
                    icon: Icon(
                        isFavorited ? Icons.favorite : Icons.favorite_border,
                        color: isFavorited ? Colors.red : Colors.white),
                  ),
                ),
              ),
            ],
          ),
          ListTile(
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (context) => PaymentScreen())),
            title: Text(name,
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.white)),
            subtitle: Text("$loc - 12 Juli 2026",
                style: const TextStyle(color: Colors.white54)),
            trailing: const Icon(Icons.arrow_forward_ios,
                size: 16, color: Colors.white54),
          ),
          // MODIFIKASI: Ditambahkan opsi Lihat Review di bagian bawah rekomendasi card
          Padding(
            padding: const EdgeInsets.only(left: 15, bottom: 10),
            child: Align(
              alignment: Alignment.centerLeft,
              child: ElevatedButton.icon(
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ReviewScreen(
                      destinationName: name,
                      reviews: widget.reviewsData[name] ?? [],
                      onAddReview: widget.onAddReview,
                    ),
                  ),
                ),
                icon: const Icon(Icons.rate_review,
                    size: 16, color: Colors.blueAccent),
                label: const Text("Lihat & Tulis Review",
                    style: TextStyle(fontSize: 12, color: Colors.white)),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white10,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20)),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}

// --- BAGIAN HALAMAN FAVORIT ---
class FavoritePage extends StatelessWidget {
  final List<Map<String, String>> favoriteList;
  final Function(String) onDelete;

  const FavoritePage(
      {super.key, required this.favoriteList, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      appBar: AppBar(
        title:
            const Text("Favorit Saya", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      body: favoriteList.isEmpty
          ? const Center(
              child: Text("Belum ada favorit",
                  style: TextStyle(color: Colors.white54)))
          : ListView.builder(
              padding: const EdgeInsets.all(20),
              itemCount: favoriteList.length,
              itemBuilder: (context, index) {
                final item = favoriteList[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 15),
                  decoration: BoxDecoration(
                      color: Colors.white10,
                      borderRadius: BorderRadius.circular(15)),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: Image.network(item['img']!,
                          width: 60, height: 60, fit: BoxFit.cover),
                    ),
                    title: Text(item['name']!,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, color: Colors.white)),
                    subtitle: Text(item['loc']!,
                        style: const TextStyle(color: Colors.white54)),
                    trailing: IconButton(
                      icon: const Icon(Icons.favorite, color: Colors.red),
                      onPressed: () => onDelete(item['name']!),
                    ),
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => PaymentScreen())),
                  ),
                );
              },
            ),
    );
  }
}

// --- BAGIAN HALAMAN REVIEW (BARU) ---
class ReviewScreen extends StatefulWidget {
  final String destinationName;
  final List<Map<String, dynamic>> reviews;
  final Function(String, String, int, String) onAddReview;

  const ReviewScreen({
    super.key,
    required this.destinationName,
    required this.reviews,
    required this.onAddReview,
  });

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  final TextEditingController _commentController = TextEditingController();
  final TextEditingController _userController = TextEditingController();
  int _selectedRating = 5;

  void _submitReview() {
    String username = _userController.text.trim().isEmpty
        ? "Anonim"
        : _userController.text.trim();
    String comment = _commentController.text.trim();

    if (comment.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text("Komentar review tidak boleh kosong!"),
            backgroundColor: Colors.redAccent),
      );
      return;
    }

    // Panggil fungsi callback untuk mengupdate state di HomeScreen
    widget.onAddReview(
        widget.destinationName, username, _selectedRating, comment);

    _commentController.clear();
    _userController.clear();
    setState(() => _selectedRating = 5);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
          content: Text("Review berhasil ditambahkan!"),
          backgroundColor: Colors.green),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      appBar: AppBar(
        title: Text("Review - ${widget.destinationName}",
            style: const TextStyle(fontSize: 16)),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Bagian Daftar Review Tersemat
          Expanded(
            child: widget.reviews.isEmpty
                ? const Center(
                    child: Text("Belum ada review untuk destinasi ini.",
                        style: TextStyle(color: Colors.white54)))
                : ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: widget.reviews.length,
                    itemBuilder: (context, index) {
                      final rev = widget.reviews[index];
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.all(15),
                        decoration: BoxDecoration(
                            color: Colors.white10,
                            borderRadius: BorderRadius.circular(15)),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(rev['user'],
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Colors.blueAccent)),
                                Row(
                                  children: List.generate(
                                    5,
                                    (i) => Icon(Icons.star,
                                        size: 14,
                                        color: i < rev['rating']
                                            ? Colors.orange
                                            : Colors.grey),
                                  ),
                                )
                              ],
                            ),
                            const SizedBox(height: 8),
                            Text(rev['comment'],
                                style: const TextStyle(
                                    color: Colors.white70, fontSize: 13)),
                          ],
                        ),
                      );
                    },
                  ),
          ),

          // Bagian Formulir Tambah Review Baru
          Container(
            padding: const EdgeInsets.all(20),
            decoration: const BoxDecoration(
              color: Color(0xFF1D2733),
              borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("Tulis Ulasan Anda",
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                const SizedBox(height: 10),
                TextField(
                  controller: _userController,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: "Nama Anda (Opsional)",
                    hintStyle: const TextStyle(color: Colors.white30),
                    filled: true,
                    fillColor: Colors.white10,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 10),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: _commentController,
                  maxLines: 2,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  decoration: InputDecoration(
                    hintText: "Tulis komentar review...",
                    hintStyle: const TextStyle(color: Colors.white30),
                    filled: true,
                    fillColor: Colors.white10,
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide.none),
                    contentPadding: const EdgeInsets.symmetric(
                        horizontal: 15, vertical: 10),
                  ),
                ),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        const Text("Rating: ",
                            style:
                                TextStyle(color: Colors.white54, fontSize: 14)),
                        Row(
                          children: List.generate(5, (index) {
                            return GestureDetector(
                              onTap: () =>
                                  setState(() => _selectedRating = index + 1),
                              child: Padding(
                                padding:
                                    const EdgeInsets.symmetric(horizontal: 2),
                                child: Icon(
                                  Icons.star,
                                  color: index < _selectedRating
                                      ? Colors.orange
                                      : Colors.grey,
                                  size: 26,
                                ),
                              ),
                            );
                          }),
                        ),
                      ],
                    ),
                    ElevatedButton(
                      onPressed: _submitReview,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blueAccent,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10)),
                      ),
                      child: const Text("Kirim",
                          style: TextStyle(color: Colors.white)),
                    )
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}

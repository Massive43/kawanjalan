import 'package:flutter/material.dart';
import 'home_screen.dart';

class PaymentScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      appBar: AppBar(
        title: const Text("Pembayaran"),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _detailCard(),
            const SizedBox(height: 20),
            const Text("Scan QRIS untuk membayar",
                style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(15),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
              ),
              child:
                  const Icon(Icons.qr_code_2, size: 200, color: Colors.black),
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () => _showSuccess(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                minimumSize: const Size(double.infinity, 55),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15)),
              ),
              child: const Text("Konfirmasi Pembayaran",
                  style: TextStyle(fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }

  Widget _detailCard() => Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: Colors.white10,
          borderRadius: BorderRadius.circular(15),
        ),
        child: Column(children: [
          _rowPrice("Biaya Wisata", "Rp 200.000"),
          _rowPrice("Biaya Pemandu", "Rp 250.000"),
          const Divider(color: Colors.white24),
          _rowPrice("Total", "Rp 450.000", isTotal: true),
        ]),
      );

  Widget _rowPrice(String label, String price, {bool isTotal = false}) =>
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(label, style: const TextStyle(color: Colors.white)),
          Text(price,
              style: TextStyle(
                  fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
                  color: isTotal ? Colors.blueAccent : Colors.white,
                  fontSize: isTotal ? 18 : 14)),
        ]),
      );

  void _showSuccess(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: const Color(0xFF1D2733),
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(25))),
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.75,
        padding: const EdgeInsets.all(25),
        child: Column(children: [
          const Icon(Icons.check_circle, color: Colors.green, size: 80),
          const SizedBox(height: 15),
          const Text("Pembayaran Berhasil!",
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white)),
          const SizedBox(height: 25),
          _detailCard(),
          const SizedBox(height: 20),
          const Text(
            "Silahkan simpan tiket Anda atau konfirmasi via WhatsApp untuk bantuan lebih lanjut.",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white70),
          ),
          const Spacer(),
          // TOMBOL LIHAT TIKET
          ElevatedButton(
            onPressed: () => _showTicketDialog(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.orangeAccent,
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            child: const Text("LIHAT TIKET",
                style: TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.black87)),
          ),
          const SizedBox(height: 12),
          TextButton(
            onPressed: () {
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(builder: (context) => const HomeScreen()),
                (route) => false,
              );
            },
            child: const Text("Kembali ke Beranda",
                style: TextStyle(color: Colors.white54)),
          )
        ]),
      ),
    );
  }

  // FUNGSI UNTUK MENAMPILKAN QR TIKET
  void _showTicketDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text("E-Ticket Wisata",
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text("Tunjukkan QR ini ke petugas di lokasi",
                style: TextStyle(color: Colors.black54, fontSize: 12)),
            const SizedBox(height: 20),
            const Icon(Icons.qr_code, size: 200, color: Colors.black),
            const SizedBox(height: 20),
            const Text("ID TIKET: KJ-9928110",
                style: TextStyle(
                    color: Colors.black, fontWeight: FontWeight.bold)),
            const Divider(),
            const Text("Destinasi: Curug Cikuluwung",
                style: TextStyle(color: Colors.black87)),
          ],
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("TUTUP")),
        ],
      ),
    );
  }
}

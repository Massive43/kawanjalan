class UserDatabase {
  // List untuk menyimpan banyak akun
  static List<Map<String, String>> users = [
    {
      "username": "user",
      "email": "user@gmail.com",
      "password": "123", // Tambahkan password default
      "phone": "+62 812-3456-7890",
    },
  ];

  // Fungsi untuk menambah user baru saat registrasi
  static void addUser(String name, String mail, String telp, String pass) {
    users.add({
      "username": name,
      "email": mail,
      "phone": telp,
      "password": pass,
    });
  }
}

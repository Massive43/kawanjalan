import 'package:flutter/material.dart';

class JadwalScreen extends StatelessWidget {
  const JadwalScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      appBar: AppBar(title: const Text('Jadwal Wisata'), backgroundColor: Colors.transparent, elevation: 0),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          _buildJadwalItem("Curug Cikuluwung", "15 Mei 2026", "Selesai", Colors.green),
          const SizedBox(height: 15),
          _buildJadwalItem("Lembang Park", "20 Juni 2026", "Mendatang", Colors.orange),
        ],
      ),
    );
  }

  Widget _buildJadwalItem(String t, String d, String s, Color c) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(15)),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)), Text(d, style: const TextStyle(color: Colors.white54))]),
        Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5), decoration: BoxDecoration(color: c.withOpacity(0.2), borderRadius: BorderRadius.circular(10), border: Border.all(color: c)), child: Text(s, style: TextStyle(color: c, fontSize: 12))),
      ],
    ),
  );
}
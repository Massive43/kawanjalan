import 'package:flutter/material.dart';
import 'login_screen.dart';
import 'home_screen.dart';
import '../data/user_data.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  // Konstanta Warna agar rapi
  static const Color scaffoldBg = Color(0xFF141D26);
  static const Color cardBg = Color(0xFF1D2733);
  static const Color primaryBlue = Color(0xFF1E58FF);
  static const Color accentPurple = Color(0xFF5E5CE6);

  @override
  Widget build(BuildContext context) {
    // Mengambil data terbaru secara sinkron dari UserDatabase
    final userData = UserDatabase.data;
    final String name = userData['username'] ?? "User";
    final String email = userData['email'] ?? "user@gmail.com";
    final String phone = userData['phone'] ?? "-";

    return Scaffold(
      backgroundColor: scaffoldBg,
      body: Column(
        children: [
          _buildHeader(context, name),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10),
                  const _SectionHeader(title: "Informasi Pribadi"),
                  _buildInformationCard(email, phone),
                  const SizedBox(height: 25),
                  const _SectionHeader(title: "Menu"),
                  _buildMenuCard(context),
                  const SizedBox(height: 30),
                  _buildLogoutButton(context),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- WIDGET HELPER ---

  Widget _buildHeader(BuildContext context, String name) {
    return Container(
      width: double.infinity,
      height: 280,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [primaryBlue, scaffoldBg],
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            _buildTopBar(context),
            const SizedBox(height: 10),
            const Text("Profil Saya",
                style: TextStyle(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
            const SizedBox(height: 15),
            const CircleAvatar(
              radius: 45,
              backgroundColor: Colors.white,
              child: Icon(Icons.person, size: 60, color: Colors.grey),
            ),
            const SizedBox(height: 10),
            Text(name,
                style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white)),
            const SizedBox(height: 5),
            _buildBadge("Wisatawan"),
          ],
        ),
      ),
    );
  }

  Widget _buildTopBar(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 15),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          TextButton.icon(
            onPressed: () => Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (context) => const HomeScreen()),
              (route) => false,
            ),
            icon: const Icon(Icons.arrow_back, color: Colors.white),
            label: const Text("Kembali", style: TextStyle(color: Colors.white)),
          ),
          const _SmallLogo(),
        ],
      ),
    );
  }

  Widget _buildBadge(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 5),
      decoration: BoxDecoration(
          color: Colors.white24, borderRadius: BorderRadius.circular(15)),
      child: Text(label,
          style: const TextStyle(color: Colors.white, fontSize: 12)),
    );
  }

  Widget _buildInformationCard(String email, String phone) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration:
          BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(15)),
      child: Column(
        children: [
          _InfoTile(
              icon: Icons.email_outlined,
              label: "Email",
              value: email,
              iconColor: Colors.blueAccent),
          const Divider(color: Colors.white10, height: 20),
          _InfoTile(
              icon: Icons.phone_outlined,
              label: "Telepon",
              value: phone,
              iconColor: Colors.greenAccent),
        ],
      ),
    );
  }

  Widget _buildMenuCard(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      decoration:
          BoxDecoration(color: cardBg, borderRadius: BorderRadius.circular(15)),
      child: Column(
        children: [
          _MenuTile(
            icon: Icons.settings_outlined,
            title: "Bantuan & Dukungan",
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SupportScreen()),
            ),
          ),
          const Divider(color: Colors.white10, height: 20),
          _MenuTile(
            icon: Icons.history,
            title: "Riwayat Wisata",
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    return ElevatedButton(
      onPressed: () => Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (context) => const LoginScreen()),
        (route) => false,
      ),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.red.shade900,
        minimumSize: const Size(double.infinity, 55),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.logout, color: Colors.white),
          SizedBox(width: 10),
          Text("Keluar",
              style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 16)),
        ],
      ),
    );
  }
}

// --- SUB-WIDGETS (COMPONENTS) ---

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 5, bottom: 10),
      child: Text(title,
          style: const TextStyle(
              color: ProfileScreen.accentPurple,
              fontSize: 16,
              fontWeight: FontWeight.bold)),
    );
  }
}

class _InfoTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color iconColor;

  const _InfoTile({
    required this.icon,
    required this.label,
    required this.value,
    required this.iconColor,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: Colors.white10, borderRadius: BorderRadius.circular(10)),
          child: Icon(icon, color: iconColor),
        ),
        const SizedBox(width: 15),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style: const TextStyle(color: Colors.white54, fontSize: 12)),
            Text(value,
                style: const TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w500)),
          ],
        )
      ],
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const _MenuTile({
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, color: Colors.blueAccent.withOpacity(0.7)),
          const SizedBox(width: 15),
          Text(title,
              style: const TextStyle(color: Colors.white, fontSize: 16)),
          const Spacer(),
          const Icon(Icons.arrow_forward_ios, size: 14, color: Colors.white24),
        ],
      ),
    );
  }
}

class _SmallLogo extends StatelessWidget {
  const _SmallLogo();

  @override
  Widget build(BuildContext context) {
    return const Row(children: [
      Text("KAWAN ",
          style:
              TextStyle(color: Color(0xFF9ACD32), fontWeight: FontWeight.bold)),
      Text("JALAN",
          style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold)),
    ]);
  }
}

// --- SUPPORT SCREEN (Halaman Bantuan) ---

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});
  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  int activeTab = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ProfileScreen.scaffoldBg,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text("Bantuan & Dukungan",
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      ),
      body: Column(
        children: [
          _buildContactCard(),
          const SizedBox(height: 20),
          _buildTabSwitcher(),
          const SizedBox(height: 20),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: _buildTabContent(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContactCard() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [ProfileScreen.primaryBlue, ProfileScreen.scaffoldBg]),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(Icons.email, color: Colors.white),
              SizedBox(width: 10),
              Text("Hubungi Kami",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 18)),
            ],
          ),
          const SizedBox(height: 10),
          const Text("Ada pertanyaan atau butuh bantuan? Hubungi kami melalui:",
              style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 15),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: Colors.white10, borderRadius: BorderRadius.circular(10)),
            child: const Row(
              children: [
                Icon(Icons.mail_outline, color: Colors.white),
                SizedBox(width: 10),
                Text("kelompok6@gmail.com",
                    style: TextStyle(color: Colors.white)),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildTabSwitcher() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      decoration: BoxDecoration(
          color: Colors.white10, borderRadius: BorderRadius.circular(15)),
      child: Row(
        children: [
          _tabButton("FAQ", 0),
          _tabButton("Saran", 1),
          _tabButton("Laporan", 2),
        ],
      ),
    );
  }

  Widget _tabButton(String label, int index) {
    bool isSelected = activeTab == index;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => activeTab = index),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? Colors.blue : Colors.transparent,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Text(label,
              textAlign: TextAlign.center,
              style: TextStyle(
                  color: isSelected ? Colors.white : Colors.white54,
                  fontWeight: FontWeight.bold)),
        ),
      ),
    );
  }

  Widget _buildTabContent() {
    switch (activeTab) {
      case 0:
        return _buildFAQ();
      case 1:
        return _buildSaran();
      case 2:
        return _buildLaporan();
      default:
        return const SizedBox();
    }
  }

  Widget _buildFAQ() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("Pertanyaan Populer",
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18)),
        const SizedBox(height: 15),
        _faqItem("Bagaimana cara memesan wisata?"),
        _faqItem("Metode pembayaran apa yang tersedia?"),
        _faqItem("Apakah saya bisa membatalkan pesanan?"),
      ],
    );
  }

  Widget _faqItem(String question) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
          color: ProfileScreen.cardBg, borderRadius: BorderRadius.circular(15)),
      child: ListTile(
        title: Text(question,
            style: const TextStyle(color: Colors.white, fontSize: 14)),
        trailing: const Icon(Icons.keyboard_arrow_down, color: Colors.white54),
      ),
    );
  }

  Widget _buildSaran() {
    return Column(
      children: [
        const Text("Saran & Masukan",
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 18)),
        const SizedBox(height: 20),
        _buildTextField("Tuliskan saran Anda di sini...", maxLines: 5),
        const SizedBox(height: 20),
        ElevatedButton.icon(
          onPressed: () {},
          icon: const Icon(Icons.send),
          label: const Text("Kirim Saran"),
          style: ElevatedButton.styleFrom(
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15))),
        )
      ],
    );
  }

  Widget _buildLaporan() {
    return Column(
      children: [
        const Row(
          children: [
            Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
            SizedBox(width: 10),
            Text("Laporkan Masalah",
                style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
          ],
        ),
        const SizedBox(height: 20),
        _buildTextField("Nama Pemandu"),
        const SizedBox(height: 15),
        _buildTextField("Deskripsi Masalah", maxLines: 4),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {},
          style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red.shade900,
              minimumSize: const Size(double.infinity, 50)),
          child: const Text("Kirim Laporan",
              style:
                  TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        )
      ],
    );
  }

  Widget _buildTextField(String hint, {int maxLines = 1}) {
    return TextField(
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white54),
        fillColor: ProfileScreen.cardBg,
        filled: true,
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide.none),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'profile_screen.dart';
import '../data/user_data.dart'; // Import database

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  bool _isAgreed = false;
  bool _obscurePassword = true;

  // STEP 1: Buat Controller untuk menangkap teks
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  void dispose() {
    // Bersihkan controller saat screen ditutup agar tidak memori leak
    _usernameController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    _passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF141D26),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 25),
          child: Column(
            children: [
              const SizedBox(height: 40),
              const Text("REGISTER",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 2)),
              const SizedBox(height: 40),

              // STEP 2: Pasang controller ke input field
              _inputField("Username", controller: _usernameController),
              const SizedBox(height: 20),
              _inputField("Email Address", controller: _emailController),
              const SizedBox(height: 20),
              _inputField("Nomor Telepon", controller: _phoneController),
              const SizedBox(height: 20),
              _inputField("Password",
                  obscure: _obscurePassword, controller: _passwordController),

              const SizedBox(height: 20),
              Row(
                children: [
                  Checkbox(
                    value: _isAgreed,
                    onChanged: (val) => setState(() => _isAgreed = val!),
                    side: const BorderSide(color: Colors.white),
                  ),
                  const Expanded(
                    child: Text("I agree to the Terms and Conditions",
                        style: TextStyle(color: Colors.white70, fontSize: 12)),
                  ),
                ],
              ),

              const SizedBox(height: 30),

              // STEP 3: Simpan data saat tombol ditekan
              ElevatedButton(
                onPressed: () {
                  if (_isAgreed) {
                    // Simpan data dari TextField ke UserDatabase
                    UserDatabase.saveUser(
                      _usernameController.text,
                      _emailController.text,
                      _phoneController.text,
                    );

                    // Navigasi ke Profile
                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const ProfileScreen()),
                      (route) => false,
                    );
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                          content: Text("Please agree to the terms")),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1E58FF),
                  minimumSize: const Size(double.infinity, 55),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15)),
                ),
                child: const Text("Sign Up",
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _inputField(String hint,
      {bool obscure = false, required TextEditingController controller}) {
    return TextField(
      controller: controller,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white54),
        filled: true,
        fillColor: const Color(0xFF1D2733),
        border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
            borderSide: BorderSide.none),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
      ),
    );
  }
}
